<?php
include('pages/index.html');

?>
