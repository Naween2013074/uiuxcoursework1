<?php
include('pages/booking_nearest_pub.html');
?>
