<?php
include('pages/booking.html');
?>
