<?php
include('pages/puzzle_introductory.html');
?>
