<?php
include('pages/drinks.html');
?>

