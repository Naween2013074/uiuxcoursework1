<?php
include('pages/newsletter_subscription.html');
?>