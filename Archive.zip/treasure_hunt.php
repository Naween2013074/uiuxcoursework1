<?php
include('pages/treasure_hunt.html');
?>

