<?php
include('pages/puzzlegame.html');
?>
