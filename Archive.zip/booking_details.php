<?php
include('pages/booking_details.html');
include('pages/footer.html');
?>
