<?php
include('pages/booking_confirmation.html');
?>

